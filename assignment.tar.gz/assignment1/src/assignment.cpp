//
// Created by Dekai WU and Serkan Kumyol on 20190307.
//
#include "assignment.hpp"

using namespace std;

// TODO: put your student ID in this variable
const char* STUDENT_ID = "20350815";

// TODO: define your global variables and helper functions here if you need. i.e. pointer to language model
language_model *lm;

/**
 * initialize your model. this function will be called before the "train" function
 */
void init() {
  // TODO: do whatever necessary to initialize your model
	lm = new language_model();
}

/**
 * train your model with a training set
 * \param dataset vector of all training data where each s is in vector of strings
 */
void lm_train(const std::vector<vector<token_T >> &dataset) {
  // TODO: complete this training function
	lm->lm_train(dataset);
}

/**
 * function to calculate shortest path of given input word using dijkstra's algorithm
 * \param word the input word
 * \return the list of top 5 anagrams paired with their distances
 */
std::vector<std::pair<vector<token_T>, double>> dijkstra(const vector<token_T> &vector_t) {
  // TODO: complete dijkstras algorithm
	std::vector<std::pair<vector<token_T>, double>> result;
	std::vector<std::pair<vector<token_T>, double>> unordermap;
	std::vector<std::pair<vector<token_T>, double>> s;
	
	std::vector<int>input_count;
	for (int i = 0; i < vector_t.size(); i++) {
		int k = 0;
		for (int j = 0; j < vector_t.size(); j++) {
			if (vector_t[i] == vector_t[j]) {
				k++;
			}
		}
		input_count.push_back(k);
	}

	for (int i = 0; i < vector_t.size(); i++) {
		std::vector<token_T> temp;
		temp.push_back(vector_t[i]);
		for (int j = 0; j < vector_t.size(); j++) {
			bool canAdd = true;
			temp.push_back[j];
			for (int k = 0; k < unordermap.size(); k++) {
				if (temp == unordermap[k].first) {
					canAdd = false;
				}
			}
			if (canAdd) {
				vector<token_T> temp1 = temp;
				temp1.pop_back();
				unordermap.push_back(make_pair(temp, lm->lm_score_suffix(vector_t[i]), temp1));
			}
			temp.pop_back();
		}
	}

	for (int i = 0; i < vector_t.size(); i++) {
		std::vector<token_T> temp;
		temp.push_back(vector_t[i]);
		bool firstCopy = true;
		for (int j = 0; j < s.size(); j++) {
			if (temp == s[j].first) {
				firstCopy = false;
			}
		}
		if (firstCopy) {
			s.push_back(make_pair(temp, lm->lm_score_suffix(vector_t[i])));
		}
	}

	bool isFinish = true;
	while (!s.empty() && isFinish)
	{
		double min = s[0].second;
		int position = 0;
		for (int i = 0; i < s.size(); i++) {
			if (min > s[i].second) {
				min = s[i].second;
				position = i;
			}
		}

		vector<token_T> u = s[position].first;
		double value = s[position].second;
		s.erase(s.begin() + position);

		if (u.size() < vector_t.size()) {
			std::vector<int> uvalue;
			for (int i = 0; i < vector_t.size(); i++) {
				int k = 0;
				for (int j = 0; j < u.size(); j++) {
					if (vector_t[i] == u[j]) {
						k++;
					}
				}
				uvalue.push_back(k);
			}
			vector<token_T> detectCopy;
			for (int i = 0; i < vector_t.size(); i++) {
				bool noCopy = true;
				for (int j = 0; j < detectCopy.size(); j++) {
					if (vector_t[i] == detectCopy[j]) {
						noCopy = false;
					}
				}

				if (uvalue[i] < input_count[i] && noCopy) {
					if (input_count[i] > 1) {
						detectCopy.push_back(vector_t[i]);
					}
					std::vector<token_T> temp = u;
					token_T a = temp.pop_back();
					std::vector<token_T> temp1;
					temp1.push_back(a);
					temp1.push_back(vector_t[i]);
					double newValue;
					for (int j = 0; j < unordermap.size(); j++) {
						if (temp1 == unordermap[j].first) {
							newValue = unordermap[j].second;
						}
					}
					temp.push_back(vector_t[i]);
					s.push_back(make_pair(temp, newValue));
				}
			}
		}
		else {
			if (result.size() < 5) {
				result.push_back(make_pair(u, value));
				for (int i = 0; i < result.size() - 1; i++) {
					if (u == result[i].first) {
						result.pop_back();
					}
				}
			}
			else
				isFinish = false;
		}
	}
	return result;
}



